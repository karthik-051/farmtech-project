-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: online_grocery_db
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products_categories`
--

DROP TABLE IF EXISTS `products_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_categories` (
  `product_id` varchar(255) NOT NULL,
  `category_id` varchar(255) NOT NULL,
  KEY `FKqt6m2o5dly3luqcm00f5t4h2p` (`category_id`),
  KEY `FKtj1vdea8qwerbjqie4xldl1el` (`product_id`),
  CONSTRAINT `FKqt6m2o5dly3luqcm00f5t4h2p` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `FKtj1vdea8qwerbjqie4xldl1el` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_categories`
--

LOCK TABLES `products_categories` WRITE;
/*!40000 ALTER TABLE `products_categories` DISABLE KEYS */;
INSERT INTO `products_categories` VALUES ('647ff1b9-076a-45ec-bbb0-74c849f83bdb','122a1fd1-222a-4ac3-b113-3515a6d64229'),('0f7d0663-e64c-4773-93f3-183a5855cb4f','609048d4-0f55-4faa-aa00-b0f3f30917fb'),('fd191680-12a9-4f9d-b512-8706ae9e0f03','609048d4-0f55-4faa-aa00-b0f3f30917fb'),('13a1ca82-62d2-4639-a375-7bbca51b4a9a','609048d4-0f55-4faa-aa00-b0f3f30917fb'),('fe2300da-ee53-4cf8-a8bc-88ece5f0ba76','58e96436-c70f-4b5c-9251-3597f95f3ba4'),('1bc2e024-45da-4aca-b9f3-37c9f3ad7d2b','58e96436-c70f-4b5c-9251-3597f95f3ba4'),('d1f784fa-fca1-47e1-bb6f-e745f528bd86','6fb6f717-ac3c-44a3-bcd3-f5bfb468b4a7');
/*!40000 ALTER TABLE `products_categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-28 15:28:10
