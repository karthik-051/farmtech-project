-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: online_grocery_db
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` varchar(255) NOT NULL,
  `deleted` bit(1) NOT NULL,
  `description` text NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES ('0f7d0663-e64c-4773-93f3-183a5855cb4f',_binary '\0','Fresh and dried turmeric roots in a wooden bowl.','http://res.cloudinary.com/mgpavlov/image/upload/v1700559133/yohopz4xmuek5jpnqwnt.jpg',' dried turmeric',10.00),('13a1ca82-62d2-4639-a375-7bbca51b4a9a',_binary '\0','The garden strawberry ','http://res.cloudinary.com/mgpavlov/image/upload/v1700559869/lw7l3gs8zrikt9fed5h0.jpg','Strawberry Plant',200.00),('1bc2e024-45da-4aca-b9f3-37c9f3ad7d2b',_binary '\0','hatsun curd is healthy curd','http://res.cloudinary.com/mgpavlov/image/upload/v1700560362/dsw2vewdwf0ctad9hnqi.webp','HatSun CURD',200.00),('647ff1b9-076a-45ec-bbb0-74c849f83bdb',_binary '','the bag with a boss','http://res.cloudinary.com/mgpavlov/image/upload/v1700308297/pjgdjlf7wumb8srbth34.webp','Mitron Bag',1.00),('d1f784fa-fca1-47e1-bb6f-e745f528bd86',_binary '','apple','http://res.cloudinary.com/mgpavlov/image/upload/v1702886339/umczszy96bhcktv2oizt.jpg','apple',19.00),('fd191680-12a9-4f9d-b512-8706ae9e0f03',_binary '\0','Editorial, Health & Wellness, Levitating Objects\r\n','http://res.cloudinary.com/mgpavlov/image/upload/v1700559440/saz4mxbtfmhbupaffgxq.jpg','Kiwi Pinball',100.00),('fe2300da-ee53-4cf8-a8bc-88ece5f0ba76',_binary '\0','all the goodness you need','http://res.cloudinary.com/mgpavlov/image/upload/v1700560179/d8d3dvjwwyu4wacutl6z.webp','Good life milk',70.00);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-28 15:28:11
