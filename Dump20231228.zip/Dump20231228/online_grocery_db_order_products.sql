-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: online_grocery_db
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order_products`
--

DROP TABLE IF EXISTS `order_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_products` (
  `id` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `product_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdxjduvg7991r4qja26fsckxv8` (`product_id`),
  CONSTRAINT `FKdxjduvg7991r4qja26fsckxv8` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_products`
--

LOCK TABLES `order_products` WRITE;
/*!40000 ALTER TABLE `order_products` DISABLE KEYS */;
INSERT INTO `order_products` VALUES ('00220081-56f2-456a-a59d-9ae23c13a34f',7.50,'0f7d0663-e64c-4773-93f3-183a5855cb4f'),('16876836-cb46-4b34-b455-d4bdeebb1f2f',20.00,'1bc2e024-45da-4aca-b9f3-37c9f3ad7d2b'),('2be9dacf-0dd6-4eb9-aeab-980c7ac97bad',15.00,'1bc2e024-45da-4aca-b9f3-37c9f3ad7d2b'),('3297111d-3bb6-4064-8b06-016834cd5edb',0.75,'647ff1b9-076a-45ec-bbb0-74c849f83bdb'),('37227058-a6b1-4c47-93cf-059495b9f099',15.00,'1bc2e024-45da-4aca-b9f3-37c9f3ad7d2b'),('488201a0-5c30-4a95-9fc1-4769b225a1dd',150.00,'13a1ca82-62d2-4639-a375-7bbca51b4a9a'),('4ae652e5-15dd-4bf4-9115-55b1f1373d58',150.00,'13a1ca82-62d2-4639-a375-7bbca51b4a9a'),('5420a645-b3f3-4c55-8a0f-aeb5b3248793',15.00,'1bc2e024-45da-4aca-b9f3-37c9f3ad7d2b'),('5e769646-054d-47e5-9048-034bb9566ffc',150.00,'13a1ca82-62d2-4639-a375-7bbca51b4a9a'),('5f51b164-73b0-4875-80e5-9e90588e841b',15.00,'1bc2e024-45da-4aca-b9f3-37c9f3ad7d2b'),('6716344f-cd1c-45fb-aef2-8165f7034787',200.00,'1bc2e024-45da-4aca-b9f3-37c9f3ad7d2b'),('679eafe5-2529-48e2-b1a6-4175fbddfd4b',10.00,'0f7d0663-e64c-4773-93f3-183a5855cb4f'),('84381df4-69da-4e8c-ab15-807367a55ddb',0.75,'647ff1b9-076a-45ec-bbb0-74c849f83bdb'),('8658a035-c895-4b2f-92dc-c7a4c8defe4c',75.00,'fd191680-12a9-4f9d-b512-8706ae9e0f03'),('8b6b48e9-29db-4f75-a3b1-95cf90676358',150.00,'13a1ca82-62d2-4639-a375-7bbca51b4a9a'),('a86ef281-560a-425a-b433-25197a9d550d',150.00,'13a1ca82-62d2-4639-a375-7bbca51b4a9a'),('adce8802-8d8c-423f-b00f-e7d8b99153ce',20.00,'1bc2e024-45da-4aca-b9f3-37c9f3ad7d2b'),('b26bb844-30f8-4070-8280-3667e92d5bef',20.00,'1bc2e024-45da-4aca-b9f3-37c9f3ad7d2b'),('b2c1a03a-9821-4a03-a38f-8c27903576cc',200.00,'13a1ca82-62d2-4639-a375-7bbca51b4a9a'),('b4ef3fb1-30ed-4896-a47c-8d3abd6edd81',1500.00,'647ff1b9-076a-45ec-bbb0-74c849f83bdb'),('c3bec012-0e42-4be9-aa7e-06115e592441',7.50,'0f7d0663-e64c-4773-93f3-183a5855cb4f'),('c6ff6b38-73d1-429d-b72b-3be09fd31373',7.50,'0f7d0663-e64c-4773-93f3-183a5855cb4f'),('ec5e558a-aa3b-4f5c-9b3e-cf00649a7f68',0.75,'647ff1b9-076a-45ec-bbb0-74c849f83bdb'),('f1681d99-2d42-4f34-aa8d-499a033a854b',52.50,'fe2300da-ee53-4cf8-a8bc-88ece5f0ba76'),('f5402a35-7b6d-4b91-8477-5d0a069878d8',7.50,'0f7d0663-e64c-4773-93f3-183a5855cb4f'),('f703da0c-29b4-4a5e-878c-f7f94a9cdd7f',7.50,'0f7d0663-e64c-4773-93f3-183a5855cb4f'),('f8671eec-8d77-4069-9e08-4d6afac91a6a',0.75,'647ff1b9-076a-45ec-bbb0-74c849f83bdb'),('f888bd6c-5e32-4060-bf2c-ccaa27fd94dc',52.50,'fe2300da-ee53-4cf8-a8bc-88ece5f0ba76'),('fe317d70-ecdf-4ce9-9420-7e0bfc9aa389',150.00,'13a1ca82-62d2-4639-a375-7bbca51b4a9a');
/*!40000 ALTER TABLE `order_products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-28 15:28:11
