-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: online_grocery_db
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` varchar(255) NOT NULL,
  `issued_on` datetime NOT NULL,
  `shipping_address` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `status_date` datetime DEFAULT NULL,
  `total_price` decimal(19,2) DEFAULT NULL,
  `customer_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKsjfs85qf6vmcurlx43cnc16gy` (`customer_id`),
  CONSTRAINT `FKsjfs85qf6vmcurlx43cnc16gy` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES ('11b604ee-c7d4-4012-ae6e-5276dfb82092','2023-11-21 13:11:51','1395 Crossman Ave Sunnyvale CA United States 94089','ACCEPTED',NULL,150.00,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('14d77958-3dbf-49f7-92be-1ca65c9c5760','2023-11-21 13:43:38','1395 Crossman Ave Sunnyvale CA United States 94089','Shipped','2023-11-22 11:02:59',20.00,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('1d776d89-68d6-44d6-85ff-8ade7990c268','2023-12-04 11:54:44','750 Daniels Way, Bloomington Indiana USA 47402','Acquired','2023-12-04 12:00:32',300.00,'0eae4fa0-20e8-4b62-857b-9d65650b911f'),('3a0b2288-eb75-4059-9084-af966dc9e198','2023-12-18 11:04:38','yalakanka mitron tech near hanuman temple','Pending',NULL,150.00,'6f1d2667-d896-4f57-90db-09f9cc5e6f3f'),('40ae0f78-c3a5-4e17-8abf-b5e824be424f','2023-11-21 11:01:52','1395 Crossman Ave Sunnyvale CA United States 94089','Acquired','2023-11-22 11:05:59',0.75,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('4947c423-bdbc-4a9f-be67-07c90af41452','2023-11-21 12:54:36','1395 Crossman Ave Sunnyvale CA United States 94089','Delivered','2023-11-29 10:59:12',27.50,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('61a97873-40b3-42ee-a93f-61946ff395c0','2023-11-22 07:18:32','1395 Crossman Ave Sunnyvale CA United States 94089','Shipped','2023-11-22 11:03:08',10.00,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('646c4208-dd24-49a5-b37f-0f4cade29e3f','2023-11-21 13:09:59','1395 Crossman Ave Sunnyvale CA United States 94089','Shipped','2023-11-22 11:02:47',165.00,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('71e1b3ac-7ab9-4e64-953c-3933c0d41f10','2023-11-21 11:04:30','13785 Research Blvd, Suite 150 Austin TX USA 78750','Delivered','2023-11-22 11:03:42',0.75,'e00e394a-0f92-41e0-bedb-b93a7005dbcb'),('7e09d993-aa78-4d1e-b123-c661091bb0bd','2023-11-21 13:41:41','1395 Crossman Ave Sunnyvale CA United States 94089','Shipped','2023-11-22 11:02:52',157.50,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('7e366fed-6069-4508-8653-4435a859ec59','2023-12-19 13:26:17','yalakanka mitron tech near hanuman temple','Pending',NULL,200.00,'6f1d2667-d896-4f57-90db-09f9cc5e6f3f'),('88fbe48c-cde2-4506-bda5-b9db187e5dc5','2023-11-21 13:42:08','1395 Crossman Ave Sunnyvale CA United States 94089','Shipped','2023-11-22 11:02:55',150.00,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('910a6685-61df-4826-bdb2-637cd1162b7c','2023-11-22 09:49:41','yalakanka mitron tech near hanuman temple','Shipped','2023-11-22 11:04:24',7.50,'6f1d2667-d896-4f57-90db-09f9cc5e6f3f'),('a4b85759-d967-4f8d-8475-7a8fe492cb01','2023-11-22 07:11:33','1395 Crossman Ave Sunnyvale CA United States 94089','Shipped','2023-11-22 11:03:05',415.00,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('aa956d78-da1f-4698-bdd1-194ab18d0d69','2023-11-21 10:58:47','1395 Crossman Ave Sunnyvale CA United States 94089','Acquired','2023-11-22 11:05:38',0.75,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('ad504135-1186-4e5d-aff2-fb57c79eb1ed','2023-12-25 11:18:13','yalakanka mitron tech near hanuman temple','Shipped','2023-12-25 11:19:04',7.50,'6f1d2667-d896-4f57-90db-09f9cc5e6f3f'),('b237a095-60bd-45e9-8abe-7941fe3c4f24','2023-11-21 07:05:47','yalakanka mitron tech near hanuman temple','Acquired','2023-11-28 07:01:01',0.75,'6f1d2667-d896-4f57-90db-09f9cc5e6f3f'),('b83632a4-a885-48f1-b59a-5ac5f40e09b0','2023-11-22 07:37:40','13785 Research Blvd, Suite 150 Austin TX USA 78750','Shipped','2023-11-22 11:04:16',15.00,'e00e394a-0f92-41e0-bedb-b93a7005dbcb'),('c47cf60b-1aa3-4368-a139-dad9eb4513c0','2023-11-22 07:19:28','1395 Crossman Ave Sunnyvale CA United States 94089','Shipped','2023-11-22 11:04:12',7.50,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('c4bfe879-f909-4955-80ea-e77d041fec30','2023-11-21 13:54:50','1395 Crossman Ave Sunnyvale CA United States 94089','Shipped','2023-11-22 11:03:02',52.50,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('da4301ad-017d-4597-9913-ce6b2afaebb9','2023-11-22 12:03:55','13785 Research Blvd, Suite 150 Austin TX USA 78750','Pending',NULL,75.00,'e00e394a-0f92-41e0-bedb-b93a7005dbcb'),('e028ed89-566e-4dbc-b53b-adbe57998f85','2023-11-18 14:02:02','1395 Crossman Ave Sunnyvale CA United States 94089','Acquired','2023-11-22 11:05:23',3000.00,'6136fe22-c44c-439c-a3c8-2de5a73c9095'),('e79d45da-67af-4e74-8ccf-2736ef25e93a','2023-11-22 09:18:57','60 E.3rd Ave,Suite 400 San Mateo CA USA 94401','Shipped','2023-11-22 11:04:20',15.00,'46901277-d972-4fd5-b7cc-08ccb4e5da60'),('fb6611fb-d550-45dd-b26f-d296820cbde1','2023-11-21 11:56:51','1395 Crossman Ave Sunnyvale CA United States 94089','Delivered','2023-11-22 11:03:45',72.50,'6136fe22-c44c-439c-a3c8-2de5a73c9095');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-28 15:28:09
