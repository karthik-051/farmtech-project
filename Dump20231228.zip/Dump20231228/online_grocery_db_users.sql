-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: online_grocery_db
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_6dotkott2kjsp8vw4d0m25fb7` (`email`),
  UNIQUE KEY `UK_r43af9ap4edm43mmtq01oddj6` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('0eae4fa0-20e8-4b62-857b-9d65650b911f','750 Daniels Way, Bloomington Indiana USA 47402','rahu@gmail.com','$2a$10$q5TUYz1jWu8p6PXqSWMhYuQwRLR4LWghzTXv7PcuqyAXOT.tiKmC.','rahul'),('11','benebenebenbenebeeenen','ss@gmail.com','ss123','ssss'),('46901277-d972-4fd5-b7cc-08ccb4e5da60','60 E.3rd Ave,Suite 400 San Mateo CA USA 94401','mitron@gmail.com','$2a$10$l/kOLkse4zS3rybHMOYS7eDmbq.Ac3jFjEO1v6naQvTwwk9Czrkzq','mitron'),('6136fe22-c44c-439c-a3c8-2de5a73c9095','1395 Crossman Ave Sunnyvale CA United States 94089','santoshchalageri1999@gmail.com','$2a$10$SRMZ4dd9/ZWrLS0C9V034upNk/zaRzFd7UVxSDj9A4XTSUsK1M3fq','ramu'),('6f1d2667-d896-4f57-90db-09f9cc5e6f3f','yalakanka mitron tech near hanuman temple','santu@gmail.com','$2a$10$AZAGOhAHzBJbEHWXdhn.S..zYDhqbrfX4.P6wBByW95rXJtwioTpu','raju'),('e00e394a-0f92-41e0-bedb-b93a7005dbcb','13785 Research Blvd, Suite 150 Austin TX USA 78750','santu1111@gmail.com','$2a$10$6trNO1ShxE5FzY/U7pb2KOEx.SX374l19BtEX3YfCQ0zuKPsRVjF6','santosh');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-28 15:28:11
