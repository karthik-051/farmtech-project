-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: online_grocery_db
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders_products`
--

DROP TABLE IF EXISTS `orders_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_products` (
  `order_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  KEY `FK9uy9gvge1wvkbiu44wl6sjm3e` (`product_id`),
  KEY `FKe4y1sseio787e4o5hrml7omt5` (`order_id`),
  CONSTRAINT `FK9uy9gvge1wvkbiu44wl6sjm3e` FOREIGN KEY (`product_id`) REFERENCES `order_products` (`id`),
  CONSTRAINT `FKe4y1sseio787e4o5hrml7omt5` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_products`
--

LOCK TABLES `orders_products` WRITE;
/*!40000 ALTER TABLE `orders_products` DISABLE KEYS */;
INSERT INTO `orders_products` VALUES ('e028ed89-566e-4dbc-b53b-adbe57998f85','b4ef3fb1-30ed-4896-a47c-8d3abd6edd81'),('e028ed89-566e-4dbc-b53b-adbe57998f85','b4ef3fb1-30ed-4896-a47c-8d3abd6edd81'),('b237a095-60bd-45e9-8abe-7941fe3c4f24','f8671eec-8d77-4069-9e08-4d6afac91a6a'),('aa956d78-da1f-4698-bdd1-194ab18d0d69','84381df4-69da-4e8c-ab15-807367a55ddb'),('40ae0f78-c3a5-4e17-8abf-b5e824be424f','3297111d-3bb6-4064-8b06-016834cd5edb'),('71e1b3ac-7ab9-4e64-953c-3933c0d41f10','ec5e558a-aa3b-4f5c-9b3e-cf00649a7f68'),('fb6611fb-d550-45dd-b26f-d296820cbde1','f888bd6c-5e32-4060-bf2c-ccaa27fd94dc'),('fb6611fb-d550-45dd-b26f-d296820cbde1','adce8802-8d8c-423f-b00f-e7d8b99153ce'),('4947c423-bdbc-4a9f-be67-07c90af41452','00220081-56f2-456a-a59d-9ae23c13a34f'),('4947c423-bdbc-4a9f-be67-07c90af41452','16876836-cb46-4b34-b455-d4bdeebb1f2f'),('646c4208-dd24-49a5-b37f-0f4cade29e3f','fe317d70-ecdf-4ce9-9420-7e0bfc9aa389'),('646c4208-dd24-49a5-b37f-0f4cade29e3f','2be9dacf-0dd6-4eb9-aeab-980c7ac97bad'),('11b604ee-c7d4-4012-ae6e-5276dfb82092','488201a0-5c30-4a95-9fc1-4769b225a1dd'),('7e09d993-aa78-4d1e-b123-c661091bb0bd','c3bec012-0e42-4be9-aa7e-06115e592441'),('7e09d993-aa78-4d1e-b123-c661091bb0bd','a86ef281-560a-425a-b433-25197a9d550d'),('88fbe48c-cde2-4506-bda5-b9db187e5dc5','4ae652e5-15dd-4bf4-9115-55b1f1373d58'),('14d77958-3dbf-49f7-92be-1ca65c9c5760','b26bb844-30f8-4070-8280-3667e92d5bef'),('c4bfe879-f909-4955-80ea-e77d041fec30','f1681d99-2d42-4f34-aa8d-499a033a854b'),('a4b85759-d967-4f8d-8475-7a8fe492cb01','b2c1a03a-9821-4a03-a38f-8c27903576cc'),('a4b85759-d967-4f8d-8475-7a8fe492cb01','b2c1a03a-9821-4a03-a38f-8c27903576cc'),('a4b85759-d967-4f8d-8475-7a8fe492cb01','5420a645-b3f3-4c55-8a0f-aeb5b3248793'),('61a97873-40b3-42ee-a93f-61946ff395c0','679eafe5-2529-48e2-b1a6-4175fbddfd4b'),('c47cf60b-1aa3-4368-a139-dad9eb4513c0','f5402a35-7b6d-4b91-8477-5d0a069878d8'),('b83632a4-a885-48f1-b59a-5ac5f40e09b0','37227058-a6b1-4c47-93cf-059495b9f099'),('e79d45da-67af-4e74-8ccf-2736ef25e93a','5f51b164-73b0-4875-80e5-9e90588e841b'),('910a6685-61df-4826-bdb2-637cd1162b7c','f703da0c-29b4-4a5e-878c-f7f94a9cdd7f'),('da4301ad-017d-4597-9913-ce6b2afaebb9','8658a035-c895-4b2f-92dc-c7a4c8defe4c'),('1d776d89-68d6-44d6-85ff-8ade7990c268','5e769646-054d-47e5-9048-034bb9566ffc'),('1d776d89-68d6-44d6-85ff-8ade7990c268','5e769646-054d-47e5-9048-034bb9566ffc'),('3a0b2288-eb75-4059-9084-af966dc9e198','8b6b48e9-29db-4f75-a3b1-95cf90676358'),('7e366fed-6069-4508-8653-4435a859ec59','6716344f-cd1c-45fb-aef2-8165f7034787'),('ad504135-1186-4e5d-aff2-fb57c79eb1ed','c6ff6b38-73d1-429d-b72b-3be09fd31373');
/*!40000 ALTER TABLE `orders_products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-28 15:28:10
